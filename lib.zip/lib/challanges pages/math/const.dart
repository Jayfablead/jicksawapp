import 'package:flutter/material.dart';

var whiteTextStyle = const TextStyle(
    fontWeight: FontWeight.bold, fontSize: 32, color: Colors.black);
var blackTextStyle = const TextStyle(
    fontWeight: FontWeight.bold, fontSize: 32, color: Colors.black);
